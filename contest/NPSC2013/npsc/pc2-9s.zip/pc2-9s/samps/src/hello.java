
//
// File:    hello.java
// Purpose: prints hello world
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
// Oct 13 1998
//
// $Id: hello.java 1962 2009-11-25 03:42:12Z boudreat $
//

public class hello {
    public static void main(String[] args) 
    {
         System.out.println("Hello World.");
    }
}

// eof
